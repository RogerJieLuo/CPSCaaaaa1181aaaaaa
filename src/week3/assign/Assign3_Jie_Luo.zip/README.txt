
I'm not able to run the command to read in the command file as input, so I manually
type the each command. The input.txt is the procedure I type command, and the
output.txt is the result from the console.

I have a little confusion about the getPrice() method in MusicStoreTester.java. It
prints the price of the specific price via "instrument.calculatePrice()", so it means
the discount that set up by MusicStore class affects the Instrument class's discount
property. Should the discount that set up by MusicStore stays in the MusicStore and
used when MusicStore objects calls getPrice() method?