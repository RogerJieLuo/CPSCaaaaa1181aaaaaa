This submission includes Assignment1.java, Self-check.txt, testPlan.txt and this README.txt.

The program was called CalInflation, now called Assignment1. Instructor prefers to keep the java file in the default package,
so in order to organize the assignments in the future, I changed the name to Assignment1.

This program is able to calculate inflation for last year according to two numbers input from users. The first number is for last year,
the second number is for current year, inflation equation is inflation = (cur - old) / old. ( * 100% for displaying).

In this program, there are certain formats that users need to know:
    there must be a comma to separate the 2 numbers, all other symbols will not be recognized
    user can not input more than two numbers.
    the first number can not be less than or equal to 0
    the second number can not be less than 0
    the number can be format as 10, 10.5, 10., +10, or .5, but it can not only be a dot
    the number can not contain any characters other than digits
Warning message will show up if anything above happen.
