
HeadView class contains the main() method, run program from this class.
HeadComponent is the component class extends from JComponent.
HeadImg contains the face, hair, eyes, nose and mouths.

There is one question:
    In order to put the head and the label paint out together, I move the head painting code from HeadComponent
    to HeadImg, then the image was delayed to show up, why would it happen?