Run ClientAndServer file to run the program.

I put some logic code in the pretended server, because the game I'm implementing needs to identify if the
players' moves are valid and switch the color of opponent's stone's color.

The game description is not clear, but go with the process list in the user manual may give you an idea
about the game.

I was planning to add a JTextArea to list the name of players and attendants that are in the game room, so that can
shows the attendants can only view the game. And add a "quit" button, so the attendants can leave the room.
But I don't have time to complete it. I may implement it in the assignment 10.