Most Exception are handled with specific message.
If there is a exception with message "Something wrong did not catch here",
then it's some exception I didn't specify. Or set DEBUG to true to track if
some unspecified exception happens while checking input/output file.