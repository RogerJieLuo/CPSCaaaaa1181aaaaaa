The data of dimension of Desktop, Laptop and Pad are static
The drawBorder function is disabled, uncomment the "drawBorder(g2);" in the draw() method of Desktop and
Laptop, then the border will display out when painting.

These file are included in a package, need to modify the package for deployment.